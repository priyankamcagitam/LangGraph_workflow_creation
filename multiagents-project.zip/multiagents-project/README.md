# Multi-Agent Task Project

This project demonstrates a multi-agent task using LangGraph where one agent writes a resume and another agent searches for jobs on the Naukri portal.

## Project Structure

```
multiagent_project/
├── src/
│   ├── multiagents/
│   │   ├── graph.py
│   │   ├── state.py
│   │   ├── configuration.py
│   │   ├── resume_writing_agent.py
│   │   ├── job_search_agent.py
│   └── multiagent_task.py
├── .github/
│   └── workflows/
│       └── multiagent-task.yml
├── .env
├── requirements.txt
└── README.md
```

## Setup

1. Clone the repository.
2. Install the dependencies:
    ```sh
    pip install -r requirements.txt
    ```
3. Create a `.env` file in the root directory with your OpenAI API key:
    ```env
    OPENAI_API_KEY=your_openai_api_key
    ```

## Running the Script Locally

To run the script locally, execute the following command:
```sh
python src/multiagent_task.py
```

## Running the Script via GitHub Actions

1. Push the code to your GitHub repository.
2. Navigate to the Actions tab in your GitHub repository.
3. Manually trigger the workflow using the `workflow_dispatch` event.

This setup ensures that the multi-agent task runs either locally or via GitHub Actions, utilizing LangGraph to manage and execute the defined tasks.