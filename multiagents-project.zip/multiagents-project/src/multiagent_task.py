import sys
import os

# Ensure the 'src' directory is in the Python path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from multiagents.graph import MultiAgentGraph
from multiagents.state import State
from multiagents.configuration import Configuration
from multiagents.resume_writing_agent import ResumeWritingAgent
from multiagents.job_search_agent import JobSearchAgent
from langgraph import Task

# Load configuration
config = Configuration()
openai_api_key = config.get_openai_api_key()

# Initialize agents
resume_writing_agent = ResumeWritingAgent(api_key=openai_api_key)
job_search_agent = JobSearchAgent()

# Create the workflow graph
graph = MultiAgentGraph()

# Define the tasks
task1 = Task(
    id="write_resume",
    agent=resume_writing_agent,
    parameters={"user_info": {
        "name": "John Doe",
        "email": "john.doe@example.com",
        "phone": "123-456-7890",
        "education": "B.Sc in Computer Science",
        "experience": "3 years as a Software Developer",
        "skills": ["Python", "JavaScript", "React", "Node.js"],
        "projects": ["Project A", "Project B"]
    }}
)

task2 = Task(
    id="search_jobs",
    agent=job_search_agent,
    parameters={"resume": "${write_resume.resume}"}
)

# Add the tasks to the workflow
graph.add_task(task1)
graph.add_task(task2)

# Define the task dependencies
graph.add_dependency("write_resume", "search_jobs")

# Execute the workflow
results = graph.execute()

# Print the results
for task_id, result in results.items():
    print(f"Task {task_id} result: {result}")