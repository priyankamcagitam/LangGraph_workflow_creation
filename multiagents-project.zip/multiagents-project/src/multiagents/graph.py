from langgraph import Agent, Workflow, Task, Executor

class MultiAgentGraph:
    def __init__(self):
        self.workflow = Workflow()

    def add_task(self, task):
        self.workflow.add_task(task)

    def add_dependency(self, task_id_from, task_id_to):
        self.workflow.add_dependency(task_id_from, task_id_to)

    def execute(self):
        executor = Executor()
        results = executor.execute(self.workflow)
        return results