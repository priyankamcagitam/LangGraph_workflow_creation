from langgraph import Agent, Task
import requests

class JobSearchAgent(Agent):
    def perform_task(self, task: Task) -> dict:
        resume = task.parameters["resume"]
        job_results = self.search_jobs(resume)
        return {"job_results": job_results}

    def search_jobs(self, resume: str) -> str:
        search_url = f"https://www.naukri.com/job-listings?resume={resume}"
        response = requests.get(search_url)
        if response.status_code == 200:
            return search_url
        else:
            return "Job search failed"