import os
from dotenv import load_dotenv

class Configuration:
    def __init__(self):
        load_dotenv()
        self.openai_api_key = os.getenv("OPENAI_API_KEY")

    def get_openai_api_key(self):
        return self.openai_api_key