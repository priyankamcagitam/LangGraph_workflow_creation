from langgraph import Agent, Task
import openai

class ResumeWritingAgent(Agent):
    def __init__(self, api_key):
        openai.api_key = api_key

    def perform_task(self, task: Task) -> dict:
        user_info = task.parameters["user_info"]
        resume = self.write_resume(user_info)
        return {"resume": resume}

    def write_resume(self, user_info: dict) -> str:
        prompt = f"Write a professional resume for the following user information:\n\n{user_info}"
        response = openai.Completion.create(
            engine="davinci-codex",
            prompt=prompt,
            max_tokens=500
        )
        resume = response.choices[0].text.strip()
        return resume